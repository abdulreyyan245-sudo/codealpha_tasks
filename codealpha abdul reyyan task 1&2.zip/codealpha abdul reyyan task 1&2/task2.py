import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import classification_report, confusion_matrix

import matplotlib
matplotlib.use('TkAgg')  # prevents freeze issue
import matplotlib.pyplot as plt

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# -----------------------
# 1. LOAD DATASET
# -----------------------
df = pd.read_csv("emotion_dataset.csv")

print("Dataset Loaded:")
print(df.head())

# -----------------------
# 2. ENCODE LABELS
# -----------------------
le = LabelEncoder()
df['label'] = le.fit_transform(df['label'])

# -----------------------
# 3. TEXT TO FEATURES
# -----------------------
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['text']).toarray()
y = df['label']

# -----------------------
# 4. TRAIN TEST SPLIT
# -----------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -----------------------
# 5. MODEL
# -----------------------
model = Sequential()
model.add(Dense(16, activation='relu', input_shape=(X.shape[1],)))
model.add(Dense(8, activation='relu'))
model.add(Dense(len(np.unique(y)), activation='softmax'))

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# -----------------------
# 6. TRAIN
# -----------------------
model.fit(X_train, y_train, epochs=50, verbose=0)

# -----------------------
# 7. PREDICTION
# -----------------------
y_pred = np.argmax(model.predict(X_test), axis=1)

# -----------------------
# 8. RESULTS
# -----------------------
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=le.classes_))

# -----------------------
# 9. CONFUSION MATRIX
# -----------------------
cm = confusion_matrix(y_test, y_pred)

plt.imshow(cm, cmap='Blues')
plt.title("Confusion Matrix")
plt.colorbar()
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()
